from flask import Flask, render_template, request, jsonify
from testeIdioma import alternar_captura_processamento

app = Flask(__name__)

# Variáveis para armazenar o texto
translation_text = "Texto de Tradução"
transcricao_text = "Texto de Transcrição"

@app.route('/')
def index():
    return render_template('index.html', translation=translation_text, transcricao=transcricao_text)


@app.route('/get_language', methods=['POST'])
def get_language():
    language = request.form['language']
    print(f"Linguagem selecionada: {language}")
    alternar_captura_processamento(language)
    return jsonify(status="success", language=language)


if __name__ == '__main__':
    app.run(debug=True)
