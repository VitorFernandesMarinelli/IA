console.log("script.js carregado");
var controle = false

function enviarLinguagem() {
    const language = document.getElementById('language').value;
    console.log("Função enviarLinguagem chamada com linguagem: " + language);
    fetch('/get_language', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({language: language})
    })
    .then(response => response.json())
    .then(data => {
        console.log("Linguagem selecionada: " + data.language);
        aviso();
    });
}

function aviso(){
    if(controle == false){
        alert("Captura iniciada");
        controle = true;
    }else{
        alert("Captura finalizada");
        controle = false;
    }
}


